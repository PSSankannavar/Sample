(function(){
	var service_app = angular.module("services", []); 
					// Resource/Restangular module injection
	service_app.service("CustomerService", function($http, $q){
		
		//this.customers = [];
		this.getCustomers = function() {
			var deferred = $q.defer();
			$http.get("customers.json").success(function(data) {
				deferred.resolve(data);
			}).
			error(function(data) {
				deferred.reject(data);
			});
		return deferred.promise;
		}
		
		/*this.getCustomer = function(id) {
			//$http.get("customers/" id)...
		}
		
		this.addCustomer = function(customer) {
			//$http.post("customers", customer).success(function(data){});
		}*/
	});
	
service_app.service("OrderService", function($http, $q){
		
		//this.customers = [];
		this.getOrders = function() {
			var deferred = $q.defer();
			$http.get("orders.json").success(function(data) {
				deferred.resolve(data);
			}).
			error(function(data) {
				deferred.reject(data);
			});
		return deferred.promise;
		}
		
		this.getOrder = function(id) {
			if(id == 1) {
				return (
						[ {
							"pid" : 100,
							"name" : "Reynolds Pen",
							"price" : 45.00
						}, {
							"pid" : 56,
							"name" : "iPhone 6",
							"price" : 54445.00
						} ]		
				);
			}
			else if(id == 2) {
				return (
						[ {
							"pid" : 108,
							"name" : "Pen",
							"price" : 45.00
						}, {
							"pid" : 98,
							"name" : "iPhone 4",
							"price" : 54445.00
						} ]		
				);
			}
		}
	
	});

})();