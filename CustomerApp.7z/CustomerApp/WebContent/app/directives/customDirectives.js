(function(){
	var directive_app = angular.module("custom_directive", []);
	directive_app.directive("cardView", function(){ //<card_view>, <card-view> are valid too
		return {
			'restrict': 'E', //E - Element, A - Attribute, C - CSS
			'controller': 'CustomerController',
			//'controllerAs': 'vm' - when not using $scope
			'templateUrl': 'app/partials/cardView.html'
			//'template': '<div {{firstName}} </div>'
		}
	});
	directive_app.directive("listView", function(){
		return {
			'restrict': 'E',
			'controller': 'CustomerController',
			'templateUrl': 'app/partials/listView.html'
		}
	});
	directive_app.directive("editPage", function(){
		return {
			'restrict': 'E',
			'controller': 'CustomerController',
			'templateUrl': 'app/partials/editPage.html'
		}
	});
	
	directive_app.directive("change", function($parse){
		return {
			'restrict': 'A',
			'link': function(scope, elem, attributes) {
				elem.on("click", function(){
					console.log(scope);
					console.log(elem);
					console.log(attributes);
					console.log("Link");
					scope.customer.address = scope.customer.address.toUpperCase();
					scope.$apply(); //Since it is a DOM event, digest loop has to be manually called using $apply()
				});
			}
		}
	});
	directive_app.directive("mystyle", function($parse){
		return {
			'restrict': 'A',
			'compile': function(elem, attributes) {
				console.log("Compile");
				elem.addClass("mycss");
			}
		}
	});
	
})();