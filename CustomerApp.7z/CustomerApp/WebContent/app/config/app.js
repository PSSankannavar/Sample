(function(){
	var app = angular.module("main_app",["customer_app","ngRoute"]);
	app.config(function($routeProvider){
		$routeProvider
		.when("/", {
			'templateUrl': 'app/pages/home.html'
		})
		.when("/customers", {
			'controller': 'CustomerController',
			'templateUrl': 'app/pages/customer.html'
		})
		.when("/orders", {
			'controller': 'OrderController',
			'templateUrl': 'app/pages/order.html'
		})
		.when("/login", {
			'controller': 'LoginController',
			'controllerAs': 'vm',
			'templateUrl': 'app/pages/login.html'
		})
		.otherwise("/");
	}).run(run);

	function run($rootScope, $location, $cookieStore, $http) {
	        $rootScope.globals = $cookieStore.get('globals') || {};
	        if ($rootScope.globals.currentUser) {
	            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
	        }

	        $rootScope.$on('$locationChangeStart', function (event, next, current) {
	            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
	            var loggedIn = $rootScope.globals.currentUser;
	            if (restrictedPage && !loggedIn) {
	                $location.path('/login');
	            }
	        });
	    }

})();