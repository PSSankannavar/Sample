(function() {
	var ang = angular.module("customer_app", []);
	ang.controller("CustomerController", function() { // this is an instance of Scope service
															 
			this.customers = customers;
			
			this.deleteCustomer = function(cust) {
				this.customers.splice(this.customers.indexOf(cust), 1);
				//$http.delete(...)
			}
			
			this.editMode = false;
			this.currentCustomer = null;
			
			this.openEditForm = function(customer) {
				this.currentCustomer = customer;
				this.editMode = true;
			}
			
			this.closeForm = function() {
				this.editMode = false;
				//$http.update(...)
			}
	});

	var customers = [ {
		"id" : 1,
		"firstName" : "Rajesh",
		"lastName" : "Kumar",
		"gender" : "male",
		"address" : "MG Road",
		"orders" : [ {
			"pid" : 100,
			"name" : "Reynolds Pen",
			"price" : 45.00
		}, {
			"pid" : 56,
			"name" : "iPhone 6",
			"price" : 54445.00
		} ]
	}, {
		"id" : 2,
		"firstName" : "Suresh",
		"lastName" : "Sharma",
		"gender" : "male",
		"address" : "VV Puram",
		"orders" : [ {
			"pid" : 88,
			"name" : "Pencil",
			"price" : 10.00
		}, {
			"pid" : 87,
			"name" : "Samsung Galaxy 6",
			"price" : 30445.00
		} ]
	}, {
		"id" : 3,
		"firstName" : "Arti",
		"lastName" : "Patil",
		"gender" : "female",
		"address" : "RR nagar",
		"orders" : [ {
			"pid" : 43,
			"name" : "Flair Pen",
			"price" : 100.00
		}, {
			"pid" : 67,
			"name" : "Moto G",
			"price" : 13000.00
		} ]
	}, {
		"id" : 4,
		"firstName" : "Varsha",
		"lastName" : "Kumar",
		"gender" : "female",
		"address" : "KR Road",
		"orders" : [ {
			"pid" : 23,
			"name" : "Test",
			"price" : 45.00
		}, {
			"pid" : 45,
			"name" : "iPhone 6",
			"price" : 34445.00
		} ]
	}, {
		"id" : 5,
		"firstName" : "Ramesh",
		"lastName" : "Kumar",
		"gender" : "male",
		"address" : "MG Road"

	} ];
})(); // Immediate Invoke Function Expression
