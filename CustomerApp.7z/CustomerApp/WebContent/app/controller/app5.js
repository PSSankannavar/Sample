(function() {
	var ang = angular.module("customer_app", []);
	
	ang.controller("CustomerMenuController", function($rootScope, $scope) {
		$scope.searchText = "";
		
				
		$scope.displayList = function(viewType) {
			$rootScope.$broadcast("filter_view",viewType)
		}
		
		$scope.updateScreen = function() {
			$rootScope.$broadcast("filter_customer", $scope.searchText);
		}
	});
	
	
	
	ang.controller("CustomerController", function($scope) { // $scope is an instance of Scope service
															 
		$scope.$on("filter_view", function(event, txt) {
			
					if(txt == 'card'){
						$scope.view = 'CardView';
						
					}
					else{
						$scope.view = 'ListView';
					}
			});
			
		
			$scope.customers = customers;
			
			$scope.customersOriginal = customers;
			
			$scope.$on("filter_customer", function(event, txt) {
				var result = [];
				$scope.customersOriginal.forEach(function(customer) {
					if(customer.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0 
						||
					customer.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0) {
						result.push(customer);
					}
				});
				$scope.customers = result;
			});
			
			
			$scope.deleteCustomer = function(cust) {
				$scope.customers.splice($scope.customers.indexOf(cust), 1);
				//$http.delete(...)
			}
			
			$scope.editMode = false;
			$scope.currentCustomer = null;
			
			$scope.openEditForm = function(customer) {
				$scope.currentCustomer = customer;
				$scope.editMode = true;
			}
			
			$scope.closeForm = function() {
				$scope.editMode = false;
				//$http.update(...)
			}
	});

	var customers = [ {
		"id" : 1,
		"firstName" : "Rajesh",
		"lastName" : "Kumar",
		"gender" : "male",
		"address" : "MG Road",
		"orders" : [ {
			"pid" : 100,
			"name" : "Reynolds Pen",
			"price" : 45.00
		}, {
			"pid" : 56,
			"name" : "iPhone 6",
			"price" : 54445.00
		} ]
	}, {
		"id" : 2,
		"firstName" : "Suresh",
		"lastName" : "Sharma",
		"gender" : "male",
		"address" : "VV Puram",
		"orders" : [ {
			"pid" : 88,
			"name" : "Pencil",
			"price" : 10.00
		}, {
			"pid" : 87,
			"name" : "Samsung Galaxy 6",
			"price" : 30445.00
		} ]
	}, {
		"id" : 3,
		"firstName" : "Arti",
		"lastName" : "Patil",
		"gender" : "female",
		"address" : "RR nagar",
		"orders" : [ {
			"pid" : 43,
			"name" : "Flair Pen",
			"price" : 100.00
		}, {
			"pid" : 67,
			"name" : "Moto G",
			"price" : 13000.00
		} ]
	}, {
		"id" : 4,
		"firstName" : "Varsha",
		"lastName" : "Kumar",
		"gender" : "female",
		"address" : "KR Road",
		"orders" : [ {
			"pid" : 23,
			"name" : "Test",
			"price" : 45.00
		}, {
			"pid" : 45,
			"name" : "iPhone 6",
			"price" : 34445.00
		} ]
	}, {
		"id" : 5,
		"firstName" : "Ramesh",
		"lastName" : "Kumar",
		"gender" : "male",
		"address" : "MG Road"

	} ];
})(); // Immediate Invoke Function Expression
