package com.aig.pc.filter;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.valves.ValveBase;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import com.aig.pc.cmnutility.exception.UnAuthorizedException;
import com.aig.pc.cmnutility.utils.Utils;
import com.aig.pc.AppConstants;
import com.aig.pc.dto.PartyMinVO;
import com.aig.pc.dto.PartyVO;
import com.aig.pc.dto.UnderwriterListVO;
import com.aig.pc.svc.IUserSvc;
import com.aig.pc.svc.UserSvcImpl;


/**
 * 
 */

/**
 * @author AIGAdmin
 *
 */
public class AuthorisationValve extends ValveBase {
	
	private static final Logger LOGGER = Logger.getLogger(AuthorisationValve.class.getName());
	
	@Override
	public void invoke(Request request, Response response) throws IOException, ServletException {

		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Start of AuthorisationValve-->invoke");
		}
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		
		try {
			
			String eid = getEIDFromRequest(httpRequest);
			saveLogAttributesinMDC(httpRequest, eid);
			authorizeUnderwriter(eid, httpRequest, request);
			String paramEid = httpRequest.getParameter( AppConstants.REQUEST_EID_PARAM );
			if(!Utils.isEmpty( paramEid ) && !eid.equalsIgnoreCase( paramEid ))
			{
				LOGGER.info( "User is Hub underwriter....Authorizing the user" );
				authorizeHubUnderwriter(eid,paramEid,httpRequest,request);
			}
		}
		catch(UnAuthorizedException exception) {
			
			Utils.logErrorMsgs(getClass(), exception);
			RequestDispatcher rd = request.getRequestDispatcher("/public/unauthorized.html");
			rd.forward(request, response);
		}
		finally {
			
			removeLogAttributesfromMDC();
		}
		
		getNext().invoke(request, response);
		
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("End of AuthorisationValve-->invoke");
		}
	}
	
	private void authorizeUnderwriter(String eId, HttpServletRequest httpRequest, Request request) {
		
		PartyVO party = null;
		
		try {
			HttpSession session = httpRequest.getSession(false);
			IUserSvc userSvcImpl = new UserSvcImpl();
			
			if(!Utils.isEmpty(session)) {
				party = (PartyVO) session.getAttribute(AppConstants.SESSION_USER_VO);
			}
			
			if(Utils.isEmpty(party) || !eId.equals(party.getEmplId())) {
				LOGGER.info( "User is not available in session  :" + eId );
				party = userSvcImpl.getPartyDetails(eId);
			}
		}
		catch(Exception exception) {
			throw new UnAuthorizedException("Underwriter Authorization Failed", "");
		}
	}

	private void authorizeHubUnderwriter( String eid,String paramEid,
			HttpServletRequest httpRequest,ServletRequest request ){
		try
		{
		 LOGGER.info( "HubUnderwriter EID :" + eid );
		 LOGGER.info( "Underwriter EID from request param :" + paramEid );
		 IUserSvc userSvcImpl = new UserSvcImpl();
		 
		 UnderwriterListVO underwriterVo = userSvcImpl.getUnderwrittersByHEmplId( eid );
		 if(Utils.isEmpty( underwriterVo )||Utils.isEmpty( underwriterVo.getPartyList()) || !partyListContainsEid(underwriterVo,paramEid))
		 {
			 throw new UnAuthorizedException("Hub Underwriter Authorization Failed","");
		 }
		}
		catch(Exception exception)
		{
			throw new UnAuthorizedException("Hub Underwriter Authorization Failed","");
		}
	}
	
	private boolean partyListContainsEid( UnderwriterListVO underwriterVo,
			String paramEid ){		
		for(PartyMinVO partyMinVO:underwriterVo.getPartyList())
		{
			if(paramEid.equalsIgnoreCase( partyMinVO.getEid() ))
			{
				return true;
			}
		}
		return false;
	}
	
	private String getEIDFromRequest(HttpServletRequest httpRequest) {
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "Start of AuthorizationValve-->getEIDFromRequest" );
		}
		
		String eId = httpRequest.getHeader(AppConstants.SMUSER_HEADER);
		String host = httpRequest.getServerName();
		LOGGER.info("Host:" + host);
		LOGGER.info("EID from request header:" + eId);
		
		if(Utils.isEmpty(eId) && host.equalsIgnoreCase(AppConstants.SERVER_HOST)) {
			LOGGER.error("NOT AN ERROR::SM_USER::"+eId);
			eId = getEidFromRequestParam(httpRequest);
		}
		
		if(Utils.isEmpty(eId)) {
			throw new UnAuthorizedException("Authorization failed as EID of user is not found in request", "");
		}
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "End of AuthorizationValve-->getEIDFromRequest" );
		}
		
		return eId;
	}
	
	private String getEidFromRequestParam(HttpServletRequest httpRequest) {
		
		LOGGER.info( "Executing this logic for region where smuser doesnot exists" );
		String eId = "";
		HttpSession session = httpRequest.getSession(false);
		PartyVO user = null;
		if(session != null) {
			user = (PartyVO) session.getAttribute(AppConstants.SESSION_USER_VO);
		}
		if(Utils.isEmpty(user)) {
			eId = httpRequest.getParameter("userid");
			if(Utils.isEmpty(eId)) {
				eId = httpRequest.getParameter(AppConstants.REQUEST_EID_PARAM);
				if(Utils.isEmpty(eId)) {
					eId = httpRequest.getParameter(AppConstants.REQUEST_HID_PARAM);
				}
			}
		}
		else {
			eId = user.getEmplId();
		}
		return eId;
	}

	private void saveLogAttributesinMDC(HttpServletRequest httpRequest, String eid) {

		String ip = httpRequest.getRemoteAddr();
		MDC.put(AppConstants.IP_LOG_ATTR, ip);
		MDC.put(AppConstants.EID_LOG_ATTR, eid);
		
	}

	private void removeLogAttributesfromMDC() {

		MDC.remove(AppConstants.IP_LOG_ATTR);
		MDC.remove(AppConstants.EID_LOG_ATTR);
	}

}
