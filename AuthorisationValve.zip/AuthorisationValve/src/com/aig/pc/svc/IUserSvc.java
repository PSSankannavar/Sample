/**
 * 
 */
package com.aig.pc.svc;

import java.sql.SQLException;

import com.aig.pc.dto.PartyVO;
import com.aig.pc.dto.UnderwriterListVO;

/**
 * @author AIGAdmin
 *
 */
public interface IUserSvc {

	PartyVO getPartyDetails(String empId);

	UnderwriterListVO getUnderwrittersByHEmplId(String eid) throws ClassNotFoundException, SQLException;
}
