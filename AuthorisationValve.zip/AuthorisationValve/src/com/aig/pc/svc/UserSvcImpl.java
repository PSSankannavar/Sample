/**
 * 
 */
package com.aig.pc.svc;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.aig.pc.cmnutility.exception.DataNotFoundException;
import com.aig.pc.cmnutility.logging.Log;
import com.aig.pc.cmnutility.utils.Utils;
import com.aig.pc.dao.IUserDao;
import com.aig.pc.dao.UserDaoImpl;
import com.aig.pc.dto.PartyVO;
import com.aig.pc.dto.UnderwriterListVO;

/**
 * @author AIGAdmin
 *
 */
public class UserSvcImpl implements IUserSvc {

	private static final Logger LOGGER = Log.getLogger(UserSvcImpl.class);
	
	IUserDao userDao = new UserDaoImpl();
	
	/* (non-Javadoc)
	 * @see com.aig.pc.svc.userdetails.IUserSvc#getPartyDetails(java.lang.String)
	 */
	@Override
	public PartyVO getPartyDetails(String empId) {
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "Start of UserSvcImpl-->getPartyDetails" );
		}
		
		PartyVO partyVO = userDao.getPartyDetails(empId);
		
		if(Utils.isEmpty(partyVO)) {
			throw new DataNotFoundException("User not found with given emp id", "");
		}
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "End of UserSvcImpl-->getPartyDetails" );
		}
		return partyVO;
		
	}

	@Override
	public UnderwriterListVO getUnderwrittersByHEmplId(String hEmpId) throws ClassNotFoundException, SQLException {
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "Start of UWMappingSvcImpl->getUnderwrittersByHEmplId" );
		}
		
		UnderwriterListVO underwriterListVO=userDao.getUnderwrittersByHEmplId ( hEmpId);
		if(Utils.isEmpty(underwriterListVO)||Utils.isEmpty(underwriterListVO.getPartyList()))
		{
			throw new DataNotFoundException("UnderWriter List is empty", "");
		}
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "End of UWMappingSvcImpl->getUnderwrittersByHEmplId" );
		}
		return underwriterListVO;
	}

}
