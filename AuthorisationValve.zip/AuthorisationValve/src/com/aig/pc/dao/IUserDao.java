/**
 * 
 */
package com.aig.pc.dao;

import java.sql.SQLException;

import com.aig.pc.dto.PartyVO;
import com.aig.pc.dto.UnderwriterListVO;

/**
 * @author AIGAdmin
 *
 */
public interface IUserDao {
	PartyVO getPartyDetails(String empId);

	UnderwriterListVO getUnderwrittersByHEmplId(String hEmpId) throws SQLException, ClassNotFoundException;
}
