/**
 * 
 */
package com.aig.pc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.aig.pc.AppConstants;
import com.aig.pc.cmnutility.logging.Log;

/**
 * @author AIGAdmin
 *
 */
public class BaseDao {

	private static final Logger LOGGER = Log.getLogger(BaseDao.class);
	
	public Connection getPCConnection() {
		
		Connection conn= null;
		
		try {
				Context initContext = new InitialContext();
				Context envContext = (Context) initContext.lookup(AppConstants.INIT_CTX);
				DataSource ds = (DataSource) envContext.lookup(AppConstants.ENV_CTX);
				conn = ds.getConnection();
		}
		catch (NamingException exception) {
			LOGGER.error(exception.getMessage(), exception);
		} catch (SQLException exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return conn;
	}
	
	protected void closeSqlConnection(ResultSet rs, Connection conn, Statement stmt) {
		try {
			if(rs != null) {
				rs.close();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		try {
			if(stmt != null) {
				stmt.close();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		try {
			if(conn != null) {
				conn.close();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
