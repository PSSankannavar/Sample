/**
 * 
 */
package com.aig.pc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import com.aig.pc.cmnutility.exception.BusinessException;
import com.aig.pc.cmnutility.logging.Log;
import com.aig.pc.dto.PartyMinVO;
import com.aig.pc.dto.PartyVO;
import com.aig.pc.dto.UnderwriterListVO;

/**
 * @author AIGAdmin
 *
 */
public class UserDaoImpl extends BaseDao implements IUserDao {

	private static final Logger LOGGER = Log.getLogger( UserDaoImpl.class );
	
	private static final String GET_PARTY_DETAILS = "SELECT EMPL_ID,FRST_NM,LAST_NM,PRTY_ID,REF_TYP_CD from TPARTY tp INNER JOIN TREFERENCE_TYPE_LOOKUP tr ON tp.PRTY_TYP_ID=tr.REF_TYP_ID where tp.EMPL_ID = ? ";
	private static final String GET_UNDERWRITERS = "SELECT * FROM TPARTY tparty WHERE tparty.PRTY_ID IN (SELECT tugm.PRTY_ID FROM TUNDERWRITER_GROUP_MEMBERSHIP tugm WHERE tugm.HUB_UW_GRP_ID IN (SELECT thugm.HUB_UW_GRP_ID FROM THUB_UNDERWRITER_GROUP_MEMBER thugm WHERE thugm.PRTY_ID= (SELECT tparty.PRTY_ID FROM Tparty tparty WHERE tparty.EMPL_ID= ? )))";	
	
	/* (non-Javadoc)
	 * @see com.aig.pc.dao.userdetails.IUserDao#getPartyDetails(java.lang.String)
	 */
	@Override
	public PartyVO getPartyDetails(String empId) {
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "Start of UserDaoImpl-->getPartyDetails" );
		}
		
		PartyVO partyVO=null;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
				
		try {
			
			con = getPCConnection();
			stmt = con.prepareStatement(GET_PARTY_DETAILS);
			stmt.setString(1, empId);
			rs = stmt.executeQuery();
			while(rs.next()) {
				partyVO = new PartyVO(rs.getString("EMPL_ID"), rs.getString("FRST_NM"), rs.getString("LAST_NM"), rs.getLong("PRTY_ID"), rs.getString("REF_TYP_CD"));
			}
		}
		catch(Exception exception) {	
			LOGGER.error(exception.getMessage(),exception);
			throw new BusinessException(exception.getMessage(),exception);
		}
		finally {
			closeSqlConnection(rs, con, stmt);
		}
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "End of UserDaoImpl-->getPartyDetails" );
		}
		return partyVO;
	}

	@Override
	public UnderwriterListVO getUnderwrittersByHEmplId(String hEmpId)  {
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "Start of UWMappingDaoJPAImpl->getUnderwrittersByHEmplId" );
		}
		
		List<PartyMinVO> list = new ArrayList<PartyMinVO>();
		UnderwriterListVO underwriterListVO = null;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try{
			con = getPCConnection();
			stmt = con.prepareStatement(GET_UNDERWRITERS);
			stmt.setString(1, hEmpId);
			rs = stmt.executeQuery();
			while(rs.next())
			{
				PartyMinVO partyMinVO = new PartyMinVO(rs.getString(1), rs.getString(2), rs.getString(3));
				list.add(partyMinVO);				
			}
			 underwriterListVO = new UnderwriterListVO(hEmpId, list);
		}catch(Exception exception) {	
			LOGGER.error(exception.getMessage(),exception);
			throw new BusinessException(exception.getMessage(),exception);
		}
		finally {
			closeSqlConnection(rs, con, stmt);
		}
		
		if( LOGGER.isDebugEnabled() ){
			LOGGER.debug( "End of UWMappingDaoJPAImpl->getUnderwrittersByHEmplId" );
		}
		return underwriterListVO;
	}

}
