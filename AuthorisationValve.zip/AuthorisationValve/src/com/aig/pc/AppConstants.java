package com.aig.pc;

public class AppConstants {

	public static final String REQUEST_EID_PARAM = "EID";
	public static final String SESSION_USER_VO = "session.user.vo";
	public static final String SMUSER_HEADER = "SM_USER";
	public static final String REQUEST_HID_PARAM = "HID";
	public static final String IP_LOG_ATTR = "IP";
	public static final String EID_LOG_ATTR = "EID";
	public static final String SERVER_HOST = "dlccwsdmart01.r1-core.r1.aig.net";
	public static final String INIT_CTX = "java:";
	public static final String ENV_CTX = "jdbc/pc_ds";
}
